ABEL KIPRUTO SANG — PERSONAL PORTFOLIO

Files:
- index.html: complete responsive portfolio website.

Preview:
Open index.html in a browser.

Publish free:
1. Create/sign in to GitHub.
2. Create a public repository named abel-kipruto-portfolio.
3. Upload index.html.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and / (root), then Save.
6. GitHub will provide your public portfolio URL after deployment.

Before publishing, add a professional email address and (optionally) LinkedIn/profile links in the Contact section. The portfolio currently does not invent contact details, employers, qualifications or project claims.
